﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeLibrary_pr11_
{
    public partial class HomeLibrary : Form
    {
        public HomeLibrary()
        {
            InitializeComponent();
        }
        public class Library
        {
            public string[] names = new string[100];
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                if (listBox1.Items.Contains(textBox1.Text + " " + textBox2.Text) == false)
                {
                    listBox1.Items.Add(textBox1.Text + " " + textBox2.Text);
                }
                else
                    MessageBox.Show("Такая книга уже есть", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Одно или более из полей для ввода пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                if (listBox1.SelectedIndex != -1)
                    if (listBox1.Items.Contains(textBox1.Text + " " + textBox2.Text) == false)
                        listBox1.Items[listBox1.SelectedIndex] = textBox1.Text + " " + textBox2.Text;
                    else
                        MessageBox.Show("Такая книга уже есть", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Строка для изменений не выбрана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Одно или более из полей для ввода для пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string[] text = listBox1.Items[listBox1.SelectedIndex].ToString().Split(' ');
                textBox1.Text = text[0];
                textBox2.Text = text[1];
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            else
                MessageBox.Show("Строка для удалений не выбрана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                if (listBox1.SelectedIndex != -1)
                    if (listBox1.Items.Contains(textBox1.Text + " " + textBox2.Text) == false)
                        listBox1.Items.Insert(listBox1.SelectedIndex, textBox1.Text + " " + textBox2.Text);
                    else
                        MessageBox.Show("Такая книга уже есть", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Строка для вставки не выбрана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Одно или более из полей для пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Sorted = true;
            listBox1.Sorted = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (listBox1.SelectedIndex != 0)
                    listBox1.SelectedIndex--;
                else
                    listBox1.SelectedIndex = listBox1.Items.Count - 1;
            }
            else
                MessageBox.Show("Строка для перемещения не выбрана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (listBox1.SelectedIndex != listBox1.Items.Count - 1)
                    listBox1.SelectedIndex++;
                else
                    listBox1.SelectedIndex = 0;
            }
            else
                MessageBox.Show("Строка для перемещения не выбрана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
