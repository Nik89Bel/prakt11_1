﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr11._1
{
    public partial class Student_work :Form
    {
        public Student_work ()
        {
            InitializeComponent();
        }
        public class Student
        {
            public string name;
            public double rost;
            private double ves = 40;
            public double GetEat(double vs)
            {
                ves = vs;
                return ves;
            }
            public double SetEat(int eda, double ves)
            {
                ves = ves + eda - 2800 / 1000;
                if (eda > 5 && eda < 10)
                {
                    ves += 0.70 * (eda * 1000 - 1600)/1000;
                }
                else ves += 0.50 * (eda * 1000 - 1800)/1000;
                return ves;
            }
            public int SetRost(int eda, double ves, int plrost)
            {
                if (eda > 5 && eda < 10)
                {
                    plrost = 1;
                    if (eda > 9)
                        plrost = 2;
                }
                else
                    plrost = 0;
                return plrost;
            }
        }

        private void label1_Click (object sender, EventArgs e)
        {

        }

        private void label2_Click (object sender, EventArgs e)
        {

        }

        private void button1_Click (object sender, EventArgs e)
        {
            int plrost = 0;
            double ves = (double) numericUpDown2.Value;
            int eda = (int) numericUpDown3.Value;
            Student stud = new Student();
            stud.name = textBox1.Text;
            stud.SetRost((int) numericUpDown3.Value, (double) numericUpDown2.Value, (int) plrost);
            stud.rost = (int) numericUpDown1.Value -(int)(stud.SetRost(eda, ves, plrost));
            stud.SetEat((int) numericUpDown3.Value, (double) numericUpDown2.Value);
            MessageBox.Show(string.Format("Студент {0}\nРост: {1}\nВес: {2}\nСьеденной еды: {3}", stud.name, stud.rost, stud.SetEat(eda, ves), (int) numericUpDown3.Value));
        }
    }
}
